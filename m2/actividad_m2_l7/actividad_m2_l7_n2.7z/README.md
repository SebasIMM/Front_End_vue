**git --version** → Muestra la versión instalada de **Git**.
**git init** → Crea un nuevo **repositorio Git** en la carpeta actual.
**git add** → Agrega archivos al **área de preparación (staging)** para el siguiente commit.
**git commit** → Guarda los **cambios agregados** en el historial del repositorio.
**git status** → Muestra el **estado actual de los archivos** (modificados, nuevos o confirmados).
